<?php
include("../seguridad.php");
include_once("../central/central.php");
include("../conexion/clsConexion.php");
?>
<div class="page-container">
  <div class="main-content">
  	<?php include('../central/cabecera.php');?>
		<blockquote class="blockquote-default" align="center">
			<p><strong><h3>INFORMACION DE SOFTWARE:<h3></strong></p>

    <p align="left"><b>SISTEMA:</b></p>
    <p align="left">PHP 7 - MYSQL</p>

    <p align="left"><b>SOFTWARE:</b></p>
    <p align="left">FARMACIA</p>

    <p align="left"><b>OPTIMIZADO POR SOFTWARE FARMACIA:</b></p>
    <p align="left"><a href="#"  target="_blank">#</a></p>
		</blockquote>
</div>
</div>
