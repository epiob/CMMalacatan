<?php
include("../seguridad.php");
include_once("../central/central.php");
include("../conexion/clsConexion.php");
?>
<div class="page-container">
  <div class="main-content">
  	<?php include('../central/cabecera.php');?>
      <div class="col-md-offset-3">
    <div class="col-md-6">

		<blockquote class="blockquote-default" align="center">
			<p>
				<strong>CREAR COPIA DE RESPALDO DE LA BASE DE DATOS</strong>
			</p>
			<p>
          <div class="row">
          	<div class="col-sm-12">
          <div class="col-sm-12">

            <div class="tile-stats tile-blue">
            <div class="icon"><i class="entypo-database"></i></div>
            <div class="num" data-start="0" data-end="vc" data-postfix="" data-duration="" data-delay="0">&nbsp;</div>
            <h3>BACKUP</h3>
            <p><a href="backup.php">Descargar</a></p>
          </div>

        </div>
      </div>
      </div>
		</blockquote>

</div>
  </div>
</div>
</div>
